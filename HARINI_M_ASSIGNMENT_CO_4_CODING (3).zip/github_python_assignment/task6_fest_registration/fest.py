"""Task 6: College Fest Registration Desk."""

import os
import re

DEPARTMENTS = ["CSE", "AIDS", "ECE", "EEE", "MECH"]
INPUT_FOLDER = "department_files"
OUTPUT_FOLDER = "reports"


def validate_email(email):
    return re.match(r"^[^@\s]+@[^@\s]+\\.[^@\s]+$", email) is not None


def process_registrations():
    master_records = []
    registered_ids = set()
    event_participants = {}
    error_messages = []

    os.makedirs(INPUT_FOLDER, exist_ok=True)
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    # Read files from all five departments
    for department in DEPARTMENTS:
        filename = os.path.join(INPUT_FOLDER, department + ".txt")
        try:
            with open(filename, "r", encoding="utf-8") as file:
                for line_number, line in enumerate(file, start=1):
                    try:
                        parts = line.strip().split(",")
                        if len(parts) != 5:
                            raise ValueError("Damaged record: expected 5 fields")

                        reg_no, name, dept, email, events = parts
                        reg_no, name, dept = reg_no.strip(), name.strip(), dept.strip()
                        email = email.strip()
                        events_list = [event.strip() for event in events.split(";") if event.strip()]

                        if not validate_email(email):
                            raise ValueError("Invalid email address")
                        if reg_no in registered_ids:
                            raise ValueError("Duplicate registration number")
                        if not events_list:
                            raise ValueError("No valid events entered")

                        registered_ids.add(reg_no)
                        record = {
                            "reg_no": reg_no,
                            "name": name,
                            "department": dept,
                            "email": email,
                            "events": events_list,
                        }
                        master_records.append(record)

                        for event in events_list:
                            event_participants.setdefault(event, []).append(record)

                    except ValueError as error:
                        error_messages.append(
                            f"{department}.txt, line {line_number}: {error}"
                        )

        except FileNotFoundError:
            error_messages.append(f"{department}.txt: File not found")
        except PermissionError:
            error_messages.append(f"{department}.txt: Permission denied")
        except UnicodeDecodeError:
            error_messages.append(f"{department}.txt: Invalid file encoding")
        except OSError as error:
            error_messages.append(f"{department}.txt: File error: {error}")

    # Master registration list
    with open(os.path.join(OUTPUT_FOLDER, "master_list.txt"), "w", encoding="utf-8") as file:
        for record in master_records:
            file.write(
                f'{record["reg_no"]},{record["name"]},{record["department"]},'
                f'{record["email"]},{";".join(record["events"])}\n'
            )

    # Event-wise participant files
    for event, participants in event_participants.items():
        safe_name = re.sub(r"[^A-Za-z0-9_-]", "_", event)
        with open(os.path.join(OUTPUT_FOLDER, safe_name + ".txt"), "w", encoding="utf-8") as file:
            for record in participants:
                file.write(f'{record["reg_no"]},{record["name"]},{record["department"]}\n')

    # Summary report
    with open(os.path.join(OUTPUT_FOLDER, "summary_report.txt"), "w", encoding="utf-8") as file:
        file.write("COLLEGE FEST REGISTRATION SUMMARY\n")
        file.write(f"Valid registrations: {len(master_records)}\n")
        file.write(f"Errors found: {len(error_messages)}\n\n")
        file.write("EVENT PARTICIPANT COUNTS\n")
        for event, participants in sorted(event_participants.items()):
            file.write(f"{event}: {len(participants)}\n")

    with open(os.path.join(OUTPUT_FOLDER, "error_log.txt"), "w", encoding="utf-8") as file:
        file.write("\n".join(error_messages) if error_messages else "No errors found.")

    print("COLLEGE FEST REGISTRATION PROCESS")
    print("Valid registrations:", len(master_records))
    print("Errors found:", len(error_messages))
    print("Reports saved in the reports folder.")
    print("\nEVENT PARTICIPANT COUNTS")
    for event, participants in sorted(event_participants.items()):
        print(event + ":", len(participants))
    print("\nProcessing completed successfully.")


if __name__ == "__main__":
    process_registrations()
