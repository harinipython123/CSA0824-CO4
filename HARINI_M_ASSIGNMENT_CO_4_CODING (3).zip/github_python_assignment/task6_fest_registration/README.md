# Task 6 – College Fest Registration Desk

Create `department_files/` and add five CSV-like text files named `CSE.txt`, `AIDS.txt`, `ECE.txt`, `EEE.txt`, and `MECH.txt`.

Each line must contain five comma-separated fields:
`register_number,name,department,email,event1;event2`

Run with `python fest.py`. Output reports are written to `reports/`.
