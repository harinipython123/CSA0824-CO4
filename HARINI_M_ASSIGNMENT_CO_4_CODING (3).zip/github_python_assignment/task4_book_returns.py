# TASK 4 - FILE AND EXCEPTION FORENSICS

# Create three sample daily files
with open("day1.txt", "w", encoding="utf-8") as f:
    f.write("Python Book\nData Science Book\n")

with open("day2.txt", "w", encoding="utf-8") as f:
    f.write("AI Book\nMachine Learning Book\n")

with open("day3.txt", "w", encoding="utf-8") as f:
    f.write("Networking Book\nCyber Security Book\n")


# Original program - showing the defects
def save_returns_old(books):
    log = open("returns_old.log", "w", encoding="utf-8")
    for book in books:
        log.write(book)
    log.close()


def process_old(day_file):
    try:
        books = open(day_file, encoding="utf-8").read().split("\n")
        save_returns_old(books)
    except FileNotFoundError:
        print("missing")


print("ORIGINAL PROGRAM OUTPUT")
for day in ["day1.txt", "day2.txt", "day3.txt"]:
    process_old(day)

with open("returns_old.log", "r", encoding="utf-8") as f:
    print("Old log contents:")
    print(f.read())


# Repaired program
def save_returns(books):
    with open("returns.log", "a", encoding="utf-8") as log:
        for book in books:
            if book.strip():
                log.write(book + "\n")


def process(day_file):
    try:
        with open(day_file, "r", encoding="utf-8") as f:
            books = f.read().splitlines()
        save_returns(books)
    except FileNotFoundError as error:
        with open("error_log.txt", "a", encoding="utf-8") as log:
            log.write(str(error) + "\n")
        print("Missing file:", day_file)


print("\nREPAIRED PROGRAM OUTPUT")
# Clear old reports before testing
open("returns.log", "w", encoding="utf-8").close()
open("error_log.txt", "w", encoding="utf-8").close()

for day in ["day1.txt", "day2.txt", "day3.txt", "day4.txt"]:
    process(day)

with open("returns.log", "r", encoding="utf-8") as f:
    print("\nFinal returns log:")
    print(f.read())

with open("error_log.txt", "r", encoding="utf-8") as f:
    print("Error log:")
    print(f.read())
