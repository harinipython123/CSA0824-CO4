# Python Programming Assignment (CO4)

Extracted and reconstructed from the uploaded assignment PDF.

## Tasks
1. `task1_mess_bill.py` – File-processing design review
2. `task2_biometric_attendance.py` – Biometric attendance files
3. `task3_attendance_exceptions.py` – Custom exception handling
4. `task4_book_returns.py` – File and exception forensics
5. `task5_attendance_organisation/` – Attendance utility organisation
6. `task6_fest_registration/` – College fest registration desk

## Run
Use Python 3:

```bash
python task1_mess_bill.py
python task2_biometric_attendance.py
python task3_attendance_exceptions.py
python task4_book_returns.py
python task5_attendance_organisation/single_script.py
python task6_fest_registration/fest.py
```

Some code in the PDF was embedded as small screenshots. Those sections have been transcribed/reconstructed from the visible code and task algorithms. Check file paths and sample input data before running.
