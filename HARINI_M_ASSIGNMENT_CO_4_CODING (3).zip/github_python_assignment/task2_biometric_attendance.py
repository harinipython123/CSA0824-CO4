from pathlib import Path

FOLDER = Path("attendance_files")
attendance = {}
processed = 0
damaged = 0

FOLDER.mkdir(exist_ok=True)

for filename in FOLDER.iterdir():
    if filename.is_file() and filename.suffix == ".txt":
        try:
            with open(filename, "r", encoding="utf-8") as file:
                for line_number, line in enumerate(file, start=1):
                    try:
                        reg_no, date, status = line.strip().split(",")
                        if status not in ("P", "A"):
                            raise ValueError("Invalid status")
                        attendance.setdefault(reg_no, {"P": 0, "A": 0})
                        attendance[reg_no][status] += 1
                    except ValueError:
                        damaged += 1
                    processed += 1
        except FileNotFoundError:
            damaged += 1

with open("attendance_report.txt", "w", encoding="utf-8") as report:
    for reg_no, counts in sorted(attendance.items()):
        total = counts["P"] + counts["A"]
        percentage = (counts["P"] / total * 100) if total else 0
        report.write(f"{reg_no},{percentage:.2f}%\n")

with open("below_75_report.txt", "w", encoding="utf-8") as report:
    for reg_no, counts in sorted(attendance.items()):
        total = counts["P"] + counts["A"]
        percentage = (counts["P"] / total * 100) if total else 0
        if percentage < 75:
            report.write(f"{reg_no},{percentage:.2f}%\n")

with open("error_log.txt", "w", encoding="utf-8") as log:
    log.write(f"Damaged records: {damaged}\n")

print("Attendance processing completed")
print("Processed files/records:", processed)
print("Damaged records:", damaged)
