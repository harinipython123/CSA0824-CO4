"""Task 5: Attendance utility organised as a single Python script."""

def read_attendance(filename):
    records = []
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            parts = line.strip().split(",")
            if len(parts) == 3:
                records.append(parts)
    return records


def calculate_statistics(records):
    print("ATTENDANCE REPORT")
    for record in records:
        reg_no, date, status = record
        print(reg_no, date, status)


def absent_three_days(records):
    print("STUDENTS ABSENT FOR THREE CONSECUTIVE DAYS")
    by_student = {}
    for reg_no, date, status in records:
        by_student.setdefault(reg_no, []).append(status)

    for reg_no, statuses in by_student.items():
        for index in range(len(statuses) - 2):
            if statuses[index:index + 3] == ["A", "A", "A"]:
                print(reg_no)
                break


def write_report(records, filename="attendance_report.txt"):
    with open(filename, "w", encoding="utf-8") as file:
        for reg_no, date, status in records:
            file.write(f"{reg_no},{date},{status}\n")


if __name__ == "__main__":
    records = read_attendance("attendance.txt")
    calculate_statistics(records)
    absent_three_days(records)
    write_report(records)
    print("Reports saved successfully.")
