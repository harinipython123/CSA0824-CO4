# Task 5 – The Same Utility Organised Four Ways

The PDF demonstrates the same attendance utility as a single script, separate module(s), three modules, and a package (`reader.py`, `stats.py`, `report.py`). `single_script.py` provides the single-script version; the remaining layouts can be split from its functions if required.
